"use strict";
const { DB } = require("./database");

const Settings = {
  getBotName: () => DB.getSetting("bot_name") || "Orlando Barbershop Bot",
  getOwner: () => DB.getSetting("owner_number") || "6285742900949",
  getAdmins: () => {
    const val = DB.getSetting("admin_numbers") || "";
    return val.split(",").map((n) => n.trim()).filter(Boolean);
  },
  getWelcomeMessage: () => DB.getSetting("welcome_message") || "Selamat datang! Ketik #menu untuk menu.",
  isAutoRead: () => DB.getSetting("auto_read") !== "false",
  isAutoReply: () => DB.getSetting("auto_reply") !== "false",
  isAntiSpam: () => DB.getSetting("anti_spam") !== "false",
  getPrefix: () => DB.getSetting("prefix") || "#",
  getRentalPrice: () => parseInt(DB.getSetting("rental_price") || "250000"),
  getRentalInstagram: () => DB.getSetting("rental_instagram") || "@D_Orlando1",
  getRentalWhatsapp: () => DB.getSetting("rental_whatsapp") || "085742900949",

  isOwner: (jid) => {
    const ownerJid = Settings.getOwner().replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    return jid === ownerJid;
  },
  isAdmin: (jid) => {
    const admins = Settings.getAdmins().map((n) => n.replace(/[^0-9]/g, "") + "@s.whatsapp.net");
    return Settings.isOwner(jid) || admins.includes(jid);
  },

  set: (key, value) => DB.setSetting(key, value),
};

module.exports = Settings;
