"use strict";
const config = require("./config");
const fs = require("fs");
const path = require("path");

let db;

// ─── SQLite ──────────────────────────────────────────────────────────────────
function initSQLite() {
  const Database = require("better-sqlite3");
  const dbPath = path.resolve(config.sqlitePath);
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  db = new Database(dbPath);
  db.pragma("journal_mode = WAL");
  createTables();
  seedDefaults();
  return db;
}

// ─── MySQL ───────────────────────────────────────────────────────────────────
let mysqlPool;
async function initMySQL() {
  const mysql = require("mysql2/promise");
  mysqlPool = await mysql.createPool({ ...config.mysql, waitForConnections: true, connectionLimit: 10 });
  await createTablesMysql();
  await seedDefaultsMysql();
  return mysqlPool;
}

// ─── Schema ──────────────────────────────────────────────────────────────────
function createTables() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS outlets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      address TEXT NOT NULL,
      maps_url TEXT,
      whatsapp TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS treatments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price INTEGER NOT NULL DEFAULT 0,
      duration INTEGER,
      description TEXT,
      photo TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price INTEGER NOT NULL DEFAULT 0,
      description TEXT,
      category TEXT,
      stock INTEGER DEFAULT 0,
      photo TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS staff (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      position TEXT,
      instagram TEXT,
      whatsapp TEXT,
      skills TEXT,
      photo TEXT,
      outlet_id INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS prices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      service_name TEXT NOT NULL,
      price INTEGER NOT NULL DEFAULT 0,
      category TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS promos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      discount TEXT,
      valid_until TEXT,
      photo TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS members (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT,
      points INTEGER DEFAULT 0,
      level TEXT DEFAULT 'Bronze',
      joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      booking_number TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      outlet_id INTEGER,
      staff_id INTEGER,
      treatment_id INTEGER,
      notes TEXT,
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS operating_hours (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      day TEXT NOT NULL UNIQUE,
      open_time TEXT NOT NULL DEFAULT '08:00',
      close_time TEXT NOT NULL DEFAULT '21:00',
      is_closed INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS bot_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key TEXT NOT NULL UNIQUE,
      value TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS broadcast_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      message TEXT NOT NULL,
      recipients INTEGER DEFAULT 0,
      failed INTEGER DEFAULT 0,
      sent_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS spam_tracker (
      jid TEXT NOT NULL,
      last_message INTEGER DEFAULT 0,
      count INTEGER DEFAULT 0,
      PRIMARY KEY (jid)
    );
  `);
}

async function createTablesMysql() {
  const tables = [
    `CREATE TABLE IF NOT EXISTS outlets (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, address TEXT NOT NULL, maps_url TEXT, whatsapp VARCHAR(50), created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS treatments (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, price INT DEFAULT 0, duration INT, description TEXT, photo TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS products (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, price INT DEFAULT 0, description TEXT, category VARCHAR(100), stock INT DEFAULT 0, photo TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS staff (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, position VARCHAR(100), instagram VARCHAR(100), whatsapp VARCHAR(50), skills TEXT, photo TEXT, outlet_id INT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS prices (id INT AUTO_INCREMENT PRIMARY KEY, service_name VARCHAR(255) NOT NULL, price INT DEFAULT 0, category VARCHAR(100), created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS promos (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255) NOT NULL, description TEXT, discount VARCHAR(50), valid_until VARCHAR(20), photo TEXT, is_active TINYINT(1) DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS members (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, phone VARCHAR(50) NOT NULL, email VARCHAR(255), points INT DEFAULT 0, level VARCHAR(20) DEFAULT 'Bronze', joined_at DATETIME DEFAULT CURRENT_TIMESTAMP, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS bookings (id INT AUTO_INCREMENT PRIMARY KEY, booking_number VARCHAR(30) NOT NULL UNIQUE, name VARCHAR(255) NOT NULL, phone VARCHAR(50) NOT NULL, date VARCHAR(20) NOT NULL, time VARCHAR(10) NOT NULL, outlet_id INT, staff_id INT, treatment_id INT, notes TEXT, status VARCHAR(20) DEFAULT 'pending', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS operating_hours (id INT AUTO_INCREMENT PRIMARY KEY, day VARCHAR(20) NOT NULL UNIQUE, open_time VARCHAR(5) DEFAULT '08:00', close_time VARCHAR(5) DEFAULT '21:00', is_closed TINYINT(1) DEFAULT 0)`,
    `CREATE TABLE IF NOT EXISTS bot_settings (id INT AUTO_INCREMENT PRIMARY KEY, \`key\` VARCHAR(100) NOT NULL UNIQUE, value TEXT, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS broadcast_logs (id INT AUTO_INCREMENT PRIMARY KEY, message TEXT NOT NULL, recipients INT DEFAULT 0, failed INT DEFAULT 0, sent_at DATETIME DEFAULT CURRENT_TIMESTAMP)`,
  ];
  for (const sql of tables) {
    await mysqlPool.execute(sql);
  }
}

function seedDefaults() {
  const days = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"];
  const stmt = db.prepare(`INSERT OR IGNORE INTO operating_hours (day, open_time, close_time, is_closed) VALUES (?, '08:00', '21:00', ?)`);
  for (const day of days) {
    stmt.run(day, day === "Minggu" ? 1 : 0);
  }
  const defaults = [
    ["bot_name", config.botName],
    ["owner_number", config.ownerNumber],
    ["admin_numbers", config.adminNumbers.join(",")],
    ["welcome_message", `Selamat datang di ${config.botName}!\nKetik ${config.prefix}menu untuk melihat layanan kami.`],
    ["auto_read", String(config.autoRead)],
    ["auto_reply", String(config.autoReply)],
    ["anti_spam", String(config.antiSpam)],
    ["rental_price", "250000"],
    ["rental_instagram", "@D_Orlando1"],
    ["rental_whatsapp", "085742900949"],
  ];
  const set = db.prepare(`INSERT OR IGNORE INTO bot_settings (key, value) VALUES (?, ?)`);
  for (const [k, v] of defaults) set.run(k, v);
}

async function seedDefaultsMysql() {
  const days = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"];
  for (const day of days) {
    await mysqlPool.execute(`INSERT IGNORE INTO operating_hours (day, open_time, close_time, is_closed) VALUES (?, '08:00', '21:00', ?)`, [day, day === "Minggu" ? 1 : 0]);
  }
}

// ─── Query helpers (SQLite sync, MySQL async) ────────────────────────────────
const DB = {
  get(table, where = {}) {
    if (config.dbType === "mysql") return this._mysqlGet(table, where);
    const keys = Object.keys(where);
    const sql = keys.length
      ? `SELECT * FROM ${table} WHERE ${keys.map((k) => `${k} = ?`).join(" AND ")}`
      : `SELECT * FROM ${table}`;
    return keys.length ? db.prepare(sql).all(...Object.values(where)) : db.prepare(sql).all();
  },
  getOne(table, where = {}) {
    if (config.dbType === "mysql") return this._mysqlGetOne(table, where);
    const keys = Object.keys(where);
    const sql = `SELECT * FROM ${table} WHERE ${keys.map((k) => `${k} = ?`).join(" AND ")} LIMIT 1`;
    return db.prepare(sql).get(...Object.values(where));
  },
  insert(table, data) {
    if (config.dbType === "mysql") return this._mysqlInsert(table, data);
    const keys = Object.keys(data);
    const sql = `INSERT INTO ${table} (${keys.join(", ")}) VALUES (${keys.map(() => "?").join(", ")})`;
    const res = db.prepare(sql).run(...Object.values(data));
    return { id: res.lastInsertRowid };
  },
  update(table, data, where = {}) {
    if (config.dbType === "mysql") return this._mysqlUpdate(table, data, where);
    const setKeys = Object.keys(data);
    const whereKeys = Object.keys(where);
    const sql = `UPDATE ${table} SET ${setKeys.map((k) => `${k} = ?`).join(", ")} WHERE ${whereKeys.map((k) => `${k} = ?`).join(" AND ")}`;
    return db.prepare(sql).run(...Object.values(data), ...Object.values(where));
  },
  delete(table, where = {}) {
    if (config.dbType === "mysql") return this._mysqlDelete(table, where);
    const keys = Object.keys(where);
    const sql = `DELETE FROM ${table} WHERE ${keys.map((k) => `${k} = ?`).join(" AND ")}`;
    return db.prepare(sql).run(...Object.values(where));
  },
  getSetting(key) {
    const row = this.getOne("bot_settings", { key });
    return row ? row.value : null;
  },
  setSetting(key, value) {
    const existing = this.getOne("bot_settings", { key });
    if (existing) this.update("bot_settings", { value, updated_at: new Date().toISOString() }, { key });
    else this.insert("bot_settings", { key, value });
  },
  // MySQL async helpers
  async _mysqlGet(table, where) {
    const keys = Object.keys(where);
    const sql = keys.length
      ? `SELECT * FROM ${table} WHERE ${keys.map((k) => `${k} = ?`).join(" AND ")}`
      : `SELECT * FROM ${table}`;
    const [rows] = await mysqlPool.execute(sql, Object.values(where));
    return rows;
  },
  async _mysqlGetOne(table, where) {
    const keys = Object.keys(where);
    const sql = `SELECT * FROM ${table} WHERE ${keys.map((k) => `${k} = ?`).join(" AND ")} LIMIT 1`;
    const [rows] = await mysqlPool.execute(sql, Object.values(where));
    return rows[0] || null;
  },
  async _mysqlInsert(table, data) {
    const keys = Object.keys(data);
    const sql = `INSERT INTO ${table} (${keys.join(", ")}) VALUES (${keys.map(() => "?").join(", ")})`;
    const [res] = await mysqlPool.execute(sql, Object.values(data));
    return { id: res.insertId };
  },
  async _mysqlUpdate(table, data, where) {
    const setKeys = Object.keys(data);
    const whereKeys = Object.keys(where);
    const sql = `UPDATE ${table} SET ${setKeys.map((k) => `${k} = ?`).join(", ")} WHERE ${whereKeys.map((k) => `${k} = ?`).join(" AND ")}`;
    await mysqlPool.execute(sql, [...Object.values(data), ...Object.values(where)]);
  },
  async _mysqlDelete(table, where) {
    const keys = Object.keys(where);
    const sql = `DELETE FROM ${table} WHERE ${keys.map((k) => `${k} = ?`).join(" AND ")}`;
    await mysqlPool.execute(sql, Object.values(where));
  },
};

async function init() {
  if (config.dbType === "mysql") {
    await initMySQL();
  } else {
    initSQLite();
  }
  return DB;
}

module.exports = { init, DB };
