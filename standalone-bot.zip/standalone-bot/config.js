require("dotenv").config();

module.exports = {
  // Bot
  botName: process.env.BOT_NAME || "Orlando Barbershop Bot",
  prefix: process.env.PREFIX || "#",

  // Owner & Admin
  ownerNumber: process.env.OWNER_NUMBER || "6285742900949",
  adminNumbers: (process.env.ADMIN_NUMBERS || "6285742900949")
    .split(",")
    .map((n) => n.trim())
    .filter(Boolean),

  // Session
  sessionName: process.env.SESSION_NAME || "orlando-session",

  // Database
  dbType: process.env.DB_TYPE || "sqlite",
  sqlitePath: process.env.SQLITE_PATH || "./database/barbershop.db",
  mysql: {
    host: process.env.MYSQL_HOST || "localhost",
    port: parseInt(process.env.MYSQL_PORT || "3306"),
    user: process.env.MYSQL_USER || "root",
    password: process.env.MYSQL_PASSWORD || "",
    database: process.env.MYSQL_DATABASE || "orlando_barbershop",
  },

  // API
  apiPort: parseInt(process.env.API_PORT || "3000"),
  apiSecret: process.env.API_SECRET || "orlando-secret-key",

  // Features
  autoRead: process.env.AUTO_READ === "true",
  autoReadStatus: process.env.AUTO_READ_STATUS === "true",
  autoReply: process.env.AUTO_REPLY !== "false",
  antiSpam: process.env.ANTI_SPAM !== "false",
  antiSpamDelay: parseInt(process.env.ANTI_SPAM_DELAY || "3000"),

  // Logging
  logLevel: process.env.LOG_LEVEL || "info",

  // Auto Backup
  autoBackupInterval: parseInt(process.env.AUTO_BACKUP_INTERVAL || "60"),

  // Developer Info (hardcoded, tidak perlu diubah)
  developer: {
    name: "Orlando Digital",
    instagram: "@D_Orlando1",
    whatsapp: "085742900949",
    copyright: "Copyright © Orlando Digital",
  },
};
