"use strict";

const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const fs = require("fs");
const path = require("path");
const qrcode = require("qrcode-terminal");

const config = require("./config");
const { init: initDB, DB } = require("./database");
const { loadPlugins, handleMessage } = require("./handler");
const { startAPI, setSocket, setQR, setConnected, setPairingCallback, clearPairingCallback } = require("./lib/api");
const logger = require("./utils/logger");

// Auto backup scheduler
const { createBackup } = require("./utils/backup");

const SESSION_DIR = path.join(__dirname, "session", config.sessionName);

// Ensure required directories exist
["session", "database", "database/backups", "assets", "public"].forEach((dir) => {
  fs.mkdirSync(path.join(__dirname, dir), { recursive: true });
});

async function startBot() {
  logger.info(`🚀 Starting ${config.botName}...`);
  logger.info(`📱 Owner: ${config.ownerNumber}`);
  logger.info(`🗄️  Database: ${config.dbType}`);

  // Initialize database
  await initDB();
  logger.info("✅ Database initialized");

  // Load plugins
  loadPlugins();

  // Start REST API
  startAPI(DB);

  // Baileys connection
  const { version, isLatest } = await fetchLatestBaileysVersion();
  logger.info(`Using WA v${version.join(".")}, isLatest: ${isLatest}`);

  async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);

    const sock = makeWASocket({
      version,
      logger: require("pino")({ level: "silent" }),
      printQRInTerminal: false,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, require("pino")({ level: "silent" })),
      },
      generateHighQualityLinkPreview: true,
      getMessage: async () => ({ conversation: "" }),
    });

    setSocket(sock);

    // Register pairing code callback so the API can trigger it on demand
    setPairingCallback(async (phone) => {
      if (sock.authState.creds.registered) {
        throw new Error("Bot sudah terhubung ke WhatsApp. Logout dulu untuk reconnect.");
      }
      logger.info(`🔑 Requesting pairing code for ${phone}...`);
      const code = await sock.requestPairingCode(phone);
      logger.info(`🔑 Pairing code: ${code}`);
      return code;
    });

    // QR Code / Connection events
    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (qr) {
        setQR(qr);
        logger.info("📲 QR Code received. Scan dengan WhatsApp kamu:");
        qrcode.generate(qr, { small: true });
        logger.info("Atau akses http://localhost:" + config.apiPort + "/api/whatsapp/qr untuk QR via API");
      }

      if (connection === "close") {
        setConnected(false);
        setQR(null);
        const shouldReconnect = (lastDisconnect?.error instanceof Boom)
          ? lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut
          : true;

        logger.warn(`Connection closed. Reconnect: ${shouldReconnect}`);

        if (shouldReconnect) {
          clearPairingCallback();
          logger.info("⏳ Reconnecting in 5 seconds...");
          setTimeout(connectToWhatsApp, 5000);
        } else {
          logger.warn("❌ Logged out. Delete session folder and restart.");
          process.exit(1);
        }
      } else if (connection === "open") {
        setConnected(true, sock.user?.id);
        setQR(null);
        logger.info(`✅ ${config.botName} connected!`);
        logger.info(`📱 Number: ${sock.user?.id}`);

        // Send startup notification to owner
        const ownerJid = config.ownerNumber.replace(/[^0-9]/g, "").replace(/^0/, "62") + "@s.whatsapp.net";
        sock.sendMessage(ownerJid, {
          text: `✅ *${config.botName}* berhasil terhubung!\n\n🕐 ${new Date().toLocaleString("id-ID")}\n📱 Nomor: ${sock.user?.id}\n\nKetik *#menu* untuk memulai.`,
        }).catch(() => {});
      }
    });

    // Save credentials on update
    sock.ev.on("creds.update", saveCreds);

    // Handle messages
    sock.ev.on("messages.upsert", async ({ messages, type }) => {
      if (type !== "notify") return;
      for (const msg of messages) {
        if (msg.key.fromMe) continue;
        await handleMessage(sock, msg);
      }
    });

    // Auto read status
    if (config.autoReadStatus) {
      sock.ev.on("messages.upsert", async ({ messages }) => {
        for (const msg of messages) {
          if (msg.key.remoteJid === "status@broadcast") {
            await sock.readMessages([msg.key]);
          }
        }
      });
    }

    return sock;
  }

  await connectToWhatsApp();

  // Auto backup scheduler
  if (config.autoBackupInterval > 0) {
    setInterval(() => {
      try {
        const result = createBackup(DB);
        logger.info(`💾 Auto backup: ${result.filename}`);
      } catch (e) {
        logger.warn(`Auto backup failed: ${e.message}`);
      }
    }, config.autoBackupInterval * 60 * 1000);
  }

  // Handle process signals
  process.on("SIGINT", () => {
    logger.info("Shutting down...");
    process.exit(0);
  });
  process.on("SIGTERM", () => {
    logger.info("Terminating...");
    process.exit(0);
  });
  process.on("uncaughtException", (err) => {
    logger.error({ err }, "Uncaught Exception");
  });
  process.on("unhandledRejection", (err) => {
    logger.error({ err }, "Unhandled Rejection");
  });
}

startBot().catch((err) => {
  logger.error({ err }, "Fatal error starting bot");
  process.exit(1);
});
