"use strict";
const Settings = require("../settings");

module.exports = {
  command: ["kontak", "contact", "instagram"],
  description: "Info kontak barbershop",
  usage: "#kontak",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const outlets = [];
    try { outlets.push(...require("../database").DB.get("outlets")); } catch {}
    let text = `☎️ *HUBUNGI KAMI*\n${"═".repeat(30)}\n\n`;
    if (outlets.length > 0) {
      outlets.forEach((o) => {
        text += `🏪 *${o.name}*\n`;
        if (o.whatsapp) text += `📱 WhatsApp: ${o.whatsapp}\n`;
        if (o.maps_url) text += `📍 Maps: ${o.maps_url}\n`;
        text += "\n";
      });
    }
    text += `📱 *Instagram:* @D_Orlando1\n`;
    text += `💬 *WhatsApp Admin:* 085742900949\n\n`;
    text += `${"═".repeat(30)}\n_Developed by Orlando Gaming_`;
    await sock.sendMessage(jid, { text });
  },
};
