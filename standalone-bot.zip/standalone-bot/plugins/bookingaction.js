"use strict";
const Settings = require("../settings");
const { DB } = require("../database");

module.exports = {
  command: ["bookingselesai", "bookingbatal", "bookinghapus", "bookinglihat"],
  description: "Aksi booking (Admin)",
  usage: "#bookingselesai [ID]",
  category: "admin",
  async execute(sock, msg, args, cmd) {
    const jid = msg.key.remoteJid;
    if (!Settings.isAdmin(jid)) {
      await sock.sendMessage(jid, { text: "❌ Akses ditolak." });
      return;
    }
    const id = parseInt(args[0]);
    if (!id) {
      await sock.sendMessage(jid, { text: `❌ Gunakan: #${cmd} [ID Booking]` });
      return;
    }
    const booking = DB.getOne("bookings", { id });
    if (!booking) {
      await sock.sendMessage(jid, { text: `❌ Booking ID ${id} tidak ditemukan.` });
      return;
    }
    if (cmd === "bookinglihat") {
      const statusIcon = { pending: "⏳", confirmed: "✅", completed: "🎉", cancelled: "❌" };
      await sock.sendMessage(jid, {
        text: `📋 *DETAIL BOOKING*\n${"═".repeat(30)}\n📌 No: ${booking.booking_number}\n👤 Nama: ${booking.name}\n📱 Phone: ${booking.phone}\n📅 Tanggal: ${booking.date}\n🕐 Jam: ${booking.time}\n${booking.notes ? `📝 Catatan: ${booking.notes}\n` : ""}Status: ${statusIcon[booking.status]} ${booking.status.toUpperCase()}`,
      });
      return;
    }
    if (cmd === "bookinghapus") {
      DB.delete("bookings", { id });
      await sock.sendMessage(jid, { text: `✅ Booking ID ${id} berhasil dihapus.` });
      return;
    }
    const newStatus = cmd === "bookingselesai" ? "completed" : "cancelled";
    DB.update("bookings", { status: newStatus }, { id });
    const icon = newStatus === "completed" ? "🎉" : "❌";
    await sock.sendMessage(jid, { text: `${icon} Booking ID ${id} (${booking.booking_number}) ditandai sebagai *${newStatus.toUpperCase()}*.` });
    // Notify customer
    const customerJid = booking.phone.replace(/[^0-9]/g, "").replace(/^0/, "62") + "@s.whatsapp.net";
    const notifMsg = newStatus === "completed"
      ? `🎉 Booking kamu (${booking.booking_number}) telah *SELESAI*. Terima kasih sudah datang ke Orlando Barbershop! 💈`
      : `❌ Booking kamu (${booking.booking_number}) telah *DIBATALKAN*. Mohon maaf atas ketidaknyamanannya. Hubungi admin untuk info lebih lanjut.`;
    sock.sendMessage(customerJid, { text: notifMsg }).catch(() => {});
  },
};
