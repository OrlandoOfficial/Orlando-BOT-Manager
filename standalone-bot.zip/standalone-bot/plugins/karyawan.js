"use strict";
const { DB } = require("../database");

module.exports = {
  command: ["karyawan"],
  description: "Lihat daftar karyawan",
  usage: "#karyawan",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const staff = DB.get("staff");
    if (!staff.length) {
      await sock.sendMessage(jid, { text: "Informasi karyawan belum tersedia." });
      return;
    }
    let text = `👨‍💼 *TIM KARYAWAN*\n${"═".repeat(30)}\n\n`;
    staff.forEach((s, i) => {
      text += `*${i + 1}. ${s.name}*\n`;
      text += `💼 Jabatan: ${s.position || "-"}\n`;
      if (s.skills) text += `⚡ Keahlian: ${s.skills}\n`;
      if (s.instagram) text += `📸 Instagram: ${s.instagram}\n`;
      if (s.whatsapp) text += `📱 WhatsApp: ${s.whatsapp}\n`;
      text += "\n";
    });
    text += `${"═".repeat(30)}\n_Booking dengan karyawan favorit kamu!_`;
    await sock.sendMessage(jid, { text });
  },
};
