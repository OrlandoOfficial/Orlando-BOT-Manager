"use strict";
const Settings = require("../settings");

module.exports = {
  command: ["home", "kembali", "back", "start"],
  description: "Kembali ke menu utama",
  usage: "#home",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const botName = Settings.getBotName();
    const prefix = Settings.getPrefix();
    const text = `🏠 *${botName}*\n${"═".repeat(30)}\n\n📋 *MENU UTAMA*\n\n${prefix}booking - 📅 Buat Booking\n${prefix}treatment - ✂️ Lihat Treatment\n${prefix}produk - 🛍️ Lihat Produk\n${prefix}harga - 💰 Daftar Harga\n${prefix}outlet - 🏪 Lokasi Outlet\n${prefix}karyawan - 👨‍💼 Tim Karyawan\n${prefix}jam - 🕒 Jam Operasional\n${prefix}promo - 🎁 Promo Aktif\n${prefix}member - 💳 Info Member\n${prefix}sewabot - 🤖 Sewa Bot\n${prefix}lokasi - 📍 Lokasi Kami\n${prefix}instagram - 📱 Instagram Kami\n${prefix}kontak - ☎️ Hubungi Kami\n${prefix}bantuan - ❓ Bantuan\n\n${"═".repeat(30)}\n_${botName}_\n_Developed by Orlando Gaming_`;
    await sock.sendMessage(jid, { text });
  },
};
