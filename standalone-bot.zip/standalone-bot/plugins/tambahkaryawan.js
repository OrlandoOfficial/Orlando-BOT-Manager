"use strict";
const Settings = require("../settings");
const { DB } = require("../database");

const state = new Map();

module.exports = {
  command: ["tambahkaryawan"],
  description: "Tambah karyawan (Admin)",
  usage: "#tambahkaryawan",
  category: "admin",
  async handleState(sock, jid, text) {
    const s = state.get(jid);
    if (!s) return false;
    const reply = async (msg) => sock.sendMessage(jid, { text: msg });
    if (s.step === "nama") { s.data.name = text; s.step = "jabatan"; await reply("💼 Jabatan/Posisi:"); return true; }
    if (s.step === "jabatan") { s.data.position = text; s.step = "keahlian"; await reply("⚡ Keahlian (pisahkan koma, atau 'skip'):"); return true; }
    if (s.step === "keahlian") { s.data.skills = text === "skip" ? null : text; s.step = "instagram"; await reply("📸 Instagram (atau 'skip'):"); return true; }
    if (s.step === "instagram") { s.data.instagram = text === "skip" ? null : text; s.step = "wa"; await reply("📱 WhatsApp karyawan (atau 'skip'):"); return true; }
    if (s.step === "wa") {
      s.data.whatsapp = text === "skip" ? null : text;
      state.delete(jid);
      DB.insert("staff", s.data);
      await reply(`✅ Karyawan *${s.data.name}* berhasil ditambahkan!`);
      return true;
    }
    return false;
  },
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    if (!Settings.isAdmin(jid)) { await sock.sendMessage(jid, { text: "❌ Akses ditolak." }); return; }
    state.set(jid, { step: "nama", data: {} });
    await sock.sendMessage(jid, { text: "👨‍💼 *TAMBAH KARYAWAN*\n\nNama karyawan:" });
  },
};
