"use strict";
const Settings = require("../settings");
const { DB } = require("../database");
const { createBackup, listBackups } = require("../utils/backup");

module.exports = {
  command: ["backup", "listbackup"],
  description: "Backup/restore database (Admin)",
  usage: "#backup",
  category: "admin",
  async execute(sock, msg, args, cmd) {
    const jid = msg.key.remoteJid;
    if (!Settings.isAdmin(jid)) { await sock.sendMessage(jid, { text: "❌ Akses ditolak." }); return; }
    if (cmd === "listbackup") {
      const backups = listBackups();
      if (!backups.length) { await sock.sendMessage(jid, { text: "📂 Belum ada backup tersimpan." }); return; }
      let text = `💾 *DAFTAR BACKUP*\n${"═".repeat(30)}\n\n`;
      backups.slice(0, 10).forEach((b, i) => {
        text += `${i + 1}. ${b.filename}\n   📅 ${new Date(b.created_at).toLocaleString("id-ID")}\n   📦 ${(b.size / 1024).toFixed(1)} KB\n\n`;
      });
      await sock.sendMessage(jid, { text });
      return;
    }
    try {
      const result = createBackup(DB);
      await sock.sendMessage(jid, { text: `✅ *Backup Berhasil!*\n📁 File: ${result.filename}\n📅 Waktu: ${new Date(result.created_at).toLocaleString("id-ID")}\n📦 Ukuran: ${(result.size / 1024).toFixed(1)} KB` });
    } catch (e) {
      await sock.sendMessage(jid, { text: `❌ Backup gagal: ${e.message}` });
    }
  },
};
