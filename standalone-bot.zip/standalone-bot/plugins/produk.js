"use strict";
const { DB } = require("../database");
const { formatRupiah } = require("../utils/format");

module.exports = {
  command: ["produk"],
  description: "Lihat daftar produk",
  usage: "#produk",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const products = DB.get("products");
    if (!products.length) {
      await sock.sendMessage(jid, { text: "Belum ada produk tersedia." });
      return;
    }
    let text = `🛍️ *DAFTAR PRODUK*\n${"═".repeat(30)}\n\n`;
    products.forEach((p, i) => {
      text += `*${i + 1}. ${p.name}*\n`;
      text += `💰 Harga: ${formatRupiah(p.price)}\n`;
      if (p.category) text += `🏷️ Kategori: ${p.category}\n`;
      if (p.description) text += `📝 ${p.description}\n`;
      text += `📦 Stok: ${p.stock > 0 ? p.stock + " unit" : "Habis"}\n\n`;
    });
    text += `${"═".repeat(30)}\n_Hubungi admin untuk pemesanan_`;
    await sock.sendMessage(jid, { text });
  },
};
