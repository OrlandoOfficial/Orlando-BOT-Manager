"use strict";
const Settings = require("../settings");

const broadcastState = new Map(); // jid -> step

module.exports = {
  command: ["broadcast", "bc"],
  description: "Kirim broadcast (Admin)",
  usage: "#broadcast [pesan]",
  category: "admin",
  handleState: null,
  async execute(sock, msg, args, cmd, { contacts } = {}) {
    const jid = msg.key.remoteJid;
    if (!Settings.isAdmin(jid)) {
      await sock.sendMessage(jid, { text: "❌ Akses ditolak." });
      return;
    }
    const message = args.join(" ");
    if (!message) {
      await sock.sendMessage(jid, { text: "❌ Gunakan: #broadcast [pesan yang akan dikirim]" });
      return;
    }
    const recipientList = contacts || [];
    if (!recipientList.length) {
      await sock.sendMessage(jid, { text: "⚠️ Tidak ada kontak tersimpan untuk broadcast.\nPesan yang akan dikirim:\n\n" + message });
      return;
    }
    await sock.sendMessage(jid, { text: `📢 Mengirim broadcast ke ${recipientList.length} kontak...` });
    let sent = 0, failed = 0;
    for (const contact of recipientList) {
      try {
        await sock.sendMessage(contact, { text: message });
        sent++;
        await new Promise((r) => setTimeout(r, 1000));
      } catch {
        failed++;
      }
    }
    await sock.sendMessage(jid, { text: `✅ Broadcast selesai!\n📤 Terkirim: ${sent}\n❌ Gagal: ${failed}` });
  },
};
