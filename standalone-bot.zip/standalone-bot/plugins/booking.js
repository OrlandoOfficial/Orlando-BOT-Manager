"use strict";
const Settings = require("../settings");
const { DB } = require("../database");
const { formatRupiah, generateBookingNumber, formatDate } = require("../utils/format");

// State machine for booking flow
const bookingState = new Map(); // jid -> { step, data }

module.exports = {
  command: ["booking"],
  description: "Buat booking/reservasi",
  usage: "#booking",
  category: "customer",

  async handleState(sock, jid, text) {
    const state = bookingState.get(jid);
    if (!state) return false;
    const { step, data } = state;

    const reply = async (msg) => sock.sendMessage(jid, { text: msg });

    if (step === "nama") {
      data.nama = text;
      bookingState.set(jid, { step: "phone", data });
      await reply("📱 Masukkan *nomor WhatsApp* kamu:");
      return true;
    }
    if (step === "phone") {
      data.phone = text;
      bookingState.set(jid, { step: "tanggal", data });
      await reply("📅 Masukkan *tanggal* booking (format: YYYY-MM-DD, contoh: 2025-08-15):");
      return true;
    }
    if (step === "tanggal") {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) {
        await reply("❌ Format tanggal salah. Gunakan format YYYY-MM-DD (contoh: 2025-08-15)");
        return true;
      }
      data.tanggal = text;
      bookingState.set(jid, { step: "jam", data });
      await reply("🕐 Masukkan *jam* booking (format: HH:MM, contoh: 10:30):");
      return true;
    }
    if (step === "jam") {
      if (!/^\d{2}:\d{2}$/.test(text)) {
        await reply("❌ Format jam salah. Gunakan format HH:MM (contoh: 10:30)");
        return true;
      }
      data.jam = text;
      const outlets = DB.get("outlets");
      let outletText = "";
      if (outlets.length > 0) {
        outletText = "\n\n🏪 *Pilih Outlet* (ketik nomor):\n";
        outlets.forEach((o, i) => { outletText += `${i + 1}. ${o.name}\n`; });
        outletText += "0. Lewati";
        bookingState.set(jid, { step: "outlet", data, outlets });
      } else {
        // No outlets — skip directly to treatment selection
        const treatments = DB.get("treatments");
        if (treatments.length > 0) {
          outletText = "\n\n✂️ *Pilih Treatment* (ketik nomor):\n";
          treatments.forEach((t, i) => { outletText += `${i + 1}. ${t.name} - ${formatRupiah(t.price)}\n`; });
          outletText += "0. Belum tahu";
          bookingState.set(jid, { step: "treatment", data, treatments });
        } else {
          bookingState.set(jid, { step: "catatan", data });
          outletText = "\n\nKetik *catatan* tambahan (atau ketik 'skip' jika tidak ada):";
        }
      }
      await reply("✅ Jam diterima." + outletText);
      return true;
    }
    if (step === "outlet") {
      const outlets = state.outlets || [];
      const idx = parseInt(text) - 1;
      if (text === "0" || text.toLowerCase() === "skip") {
        data.outlet_id = null;
      } else if (idx >= 0 && idx < outlets.length) {
        data.outlet_id = outlets[idx].id;
        data.outlet_name = outlets[idx].name;
      } else {
        await reply("❌ Pilihan tidak valid. Ketik nomor yang tersedia atau 0 untuk lewati.");
        return true;
      }
      const staff = DB.get("staff");
      let staffText = "\n\n👨‍💼 *Pilih Karyawan* (ketik nomor):\n";
      if (staff.length > 0) {
        staff.forEach((s, i) => { staffText += `${i + 1}. ${s.name} - ${s.position}\n`; });
        staffText += "0. Siapa saja";
        bookingState.set(jid, { step: "karyawan", data, outlets: state.outlets, staff });
      } else {
        bookingState.set(jid, { step: "catatan", data });
        staffText = "\n\nKetik *catatan* tambahan (atau 'skip'):";
      }
      await reply("✅ Outlet dipilih." + staffText);
      return true;
    }
    if (step === "karyawan") {
      const staff = state.staff || [];
      const idx = parseInt(text) - 1;
      if (text === "0" || text.toLowerCase() === "skip") {
        data.staff_id = null;
      } else if (idx >= 0 && idx < staff.length) {
        data.staff_id = staff[idx].id;
        data.staff_name = staff[idx].name;
      } else {
        await reply("❌ Pilihan tidak valid.");
        return true;
      }
      const treatments = DB.get("treatments");
      let treatText = "\n\n✂️ *Pilih Treatment* (ketik nomor):\n";
      if (treatments.length > 0) {
        treatments.forEach((t, i) => { treatText += `${i + 1}. ${t.name} - ${formatRupiah(t.price)}\n`; });
        treatText += "0. Belum tahu";
        bookingState.set(jid, { step: "treatment", data, outlets: state.outlets, staff: state.staff, treatments });
      } else {
        bookingState.set(jid, { step: "catatan", data });
        treatText = "\n\nKetik *catatan* tambahan (atau 'skip'):";
      }
      await reply("✅ Karyawan dipilih." + treatText);
      return true;
    }
    if (step === "treatment") {
      const treatments = state.treatments || [];
      const idx = parseInt(text) - 1;
      if (text === "0" || text.toLowerCase() === "skip") {
        data.treatment_id = null;
      } else if (idx >= 0 && idx < treatments.length) {
        data.treatment_id = treatments[idx].id;
        data.treatment_name = treatments[idx].name;
      } else {
        await reply("❌ Pilihan tidak valid.");
        return true;
      }
      bookingState.set(jid, { ...state, step: "catatan", data });
      await reply("📝 Ketik *catatan* tambahan (atau ketik 'skip' jika tidak ada):");
      return true;
    }
    if (step === "catatan") {
      data.catatan = text.toLowerCase() === "skip" ? null : text;
      bookingState.delete(jid);
      // Save booking
      const bookingNumber = generateBookingNumber();
      DB.insert("bookings", {
        booking_number: bookingNumber,
        name: data.nama,
        phone: data.phone,
        date: data.tanggal,
        time: data.jam,
        outlet_id: data.outlet_id || null,
        staff_id: data.staff_id || null,
        treatment_id: data.treatment_id || null,
        notes: data.catatan || null,
        status: "pending",
      });
      // Notify owner
      const owner = Settings.getOwner();
      const ownerJid = owner.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
      const notif = `🔔 *BOOKING BARU!*\n${"═".repeat(30)}\n📋 No. Booking: *${bookingNumber}*\n👤 Nama: ${data.nama}\n📱 WA: ${data.phone}\n📅 Tanggal: ${formatDate(data.tanggal)}\n🕐 Jam: ${data.jam}\n${data.outlet_name ? `🏪 Outlet: ${data.outlet_name}\n` : ""}${data.staff_name ? `👨‍💼 Karyawan: ${data.staff_name}\n` : ""}${data.treatment_name ? `✂️ Treatment: ${data.treatment_name}\n` : ""}${data.catatan ? `📝 Catatan: ${data.catatan}\n` : ""}\nStatus: ⏳ Pending`;
      sock.sendMessage(ownerJid, { text: notif }).catch(() => {});
      await reply(`✅ *Booking Berhasil!*\n${"═".repeat(30)}\n📋 Nomor Booking: *${bookingNumber}*\n👤 Nama: ${data.nama}\n📅 Tanggal: ${formatDate(data.tanggal)}\n🕐 Jam: ${data.jam}\n\n⏳ Status booking kamu: *Menunggu Konfirmasi*\n\nAdmin kami akan segera menghubungi kamu. Terima kasih! 🙏`);
      return true;
    }
    return false;
  },

  async execute(sock, msg, args) {
    const jid = msg.key.remoteJid;
    bookingState.set(jid, { step: "nama", data: {} });
    await sock.sendMessage(jid, { text: `📅 *BUAT BOOKING*\n${"═".repeat(30)}\n\nMari kita mulai proses booking!\n\n👤 Masukkan *nama lengkap* kamu:` });
  },
};
