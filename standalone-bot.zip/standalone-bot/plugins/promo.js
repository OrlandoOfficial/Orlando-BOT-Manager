"use strict";
const { DB } = require("../database");

module.exports = {
  command: ["promo"],
  description: "Lihat promo aktif",
  usage: "#promo",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const promos = DB.get("promos").filter((p) => p.is_active);
    if (!promos.length) {
      await sock.sendMessage(jid, { text: "Tidak ada promo yang aktif saat ini." });
      return;
    }
    let text = `🎁 *PROMO AKTIF*\n${"═".repeat(30)}\n\n`;
    promos.forEach((p, i) => {
      text += `🔥 *${i + 1}. ${p.title}*\n`;
      if (p.description) text += `📝 ${p.description}\n`;
      if (p.discount) text += `💸 Diskon: ${p.discount}\n`;
      if (p.valid_until) text += `📅 Berlaku hingga: ${p.valid_until}\n`;
      text += "\n";
    });
    text += `${"═".repeat(30)}\n_Segera manfaatkan promo sebelum habis!_`;
    await sock.sendMessage(jid, { text });
  },
};
