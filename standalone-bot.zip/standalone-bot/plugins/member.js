"use strict";
const { DB } = require("../database");

module.exports = {
  command: ["member", "kartu"],
  description: "Info program member",
  usage: "#member",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const senderPhone = jid.replace("@s.whatsapp.net", "").replace(/^62/, "0");
    const member = DB.getOne("members", { phone: senderPhone }) ||
      DB.getOne("members", { phone: jid.replace("@s.whatsapp.net", "") });
    let text = `💳 *PROGRAM MEMBER*\n${"═".repeat(30)}\n\n`;
    if (member) {
      const levelEmoji = member.level === "Gold" ? "🥇" : member.level === "Silver" ? "🥈" : "🥉";
      text += `✅ *Kamu sudah menjadi member!*\n\n`;
      text += `👤 Nama: ${member.name}\n`;
      text += `📱 Phone: ${member.phone}\n`;
      text += `${levelEmoji} Level: ${member.level}\n`;
      text += `⭐ Poin: ${member.points}\n`;
      text += `📅 Bergabung: ${new Date(member.joined_at).toLocaleDateString("id-ID")}\n\n`;
      text += `📊 *Level Member:*\n`;
      text += `🥉 Bronze: 0 - 99 poin\n`;
      text += `🥈 Silver: 100 - 499 poin\n`;
      text += `🥇 Gold: 500+ poin\n`;
    } else {
      text += `❌ Kamu belum terdaftar sebagai member.\n\n`;
      text += `📊 *Keuntungan Member:*\n`;
      text += `✨ Diskon khusus member\n`;
      text += `⭐ Sistem poin reward\n`;
      text += `🎁 Hadiah ulang tahun\n`;
      text += `📱 Info promo eksklusif\n\n`;
      text += `📋 *Level Member:*\n`;
      text += `🥉 Bronze: 0 - 99 poin\n`;
      text += `🥈 Silver: 100 - 499 poin\n`;
      text += `🥇 Gold: 500+ poin\n\n`;
      text += `_Hubungi admin untuk mendaftar sebagai member!_`;
    }
    text += `\n${"═".repeat(30)}`;
    await sock.sendMessage(jid, { text });
  },
};
