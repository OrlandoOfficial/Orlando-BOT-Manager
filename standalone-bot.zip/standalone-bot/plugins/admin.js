"use strict";
const Settings = require("../settings");

module.exports = {
  command: ["admin", "owner"],
  description: "Menu admin/owner",
  usage: "#admin",
  category: "admin",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    if (!Settings.isAdmin(jid)) {
      await sock.sendMessage(jid, { text: "❌ Akses ditolak. Menu ini hanya untuk Admin/Owner." });
      return;
    }
    const prefix = Settings.getPrefix();
    const text = `🔐 *DASHBOARD ADMIN*\n${"═".repeat(30)}\n\n📅 *BOOKING*\n${prefix}bookinglist - Daftar booking\n${prefix}bookingselesai [ID] - Tandai selesai\n${prefix}bookingbatal [ID] - Tandai batal\n${prefix}bookinghapus [ID] - Hapus booking\n\n🛍️ *PRODUK*\n${prefix}tambahproduk - Tambah produk\n${prefix}editproduk [ID] - Edit produk\n${prefix}hapusproduk [ID] - Hapus produk\n\n✂️ *TREATMENT*\n${prefix}tambahtreatment - Tambah treatment\n${prefix}edittreatment [ID] - Edit treatment\n${prefix}hapustreatment [ID] - Hapus treatment\n\n🏪 *OUTLET*\n${prefix}tambahoutlet - Tambah outlet\n${prefix}editoutlet [ID] - Edit outlet\n${prefix}hapusoutlet [ID] - Hapus outlet\n\n👨‍💼 *KARYAWAN*\n${prefix}tambahkaryawan - Tambah karyawan\n${prefix}editkaryawan [ID] - Edit karyawan\n${prefix}hapuskaryawan [ID] - Hapus karyawan\n\n💰 *HARGA & PROMO*\n${prefix}tambahpromo - Tambah promo\n${prefix}editpromo [ID] - Edit promo\n${prefix}hapuspromo [ID] - Hapus promo\n\n📢 *BROADCAST*\n${prefix}broadcast [pesan] - Kirim broadcast\n\n💾 *DATABASE*\n${prefix}backup - Backup database\n${prefix}listbackup - Daftar backup\n\n${"═".repeat(30)}`;
    await sock.sendMessage(jid, { text });
  },
};
