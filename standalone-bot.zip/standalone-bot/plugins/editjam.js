"use strict";
const Settings = require("../settings");
const { DB } = require("../database");

module.exports = {
  command: ["editjam"],
  description: "Edit jam operasional (Admin)",
  usage: "#editjam [Hari] [jam_buka] [jam_tutup] atau #editjam [Hari] tutup",
  category: "admin",
  async execute(sock, msg, args) {
    const jid = msg.key.remoteJid;
    if (!Settings.isAdmin(jid)) { await sock.sendMessage(jid, { text: "❌ Akses ditolak." }); return; }
    if (args.length < 2) {
      await sock.sendMessage(jid, { text: "❌ Format: #editjam [Hari] [jam_buka] [jam_tutup]\nContoh: #editjam Senin 08:00 21:00\nAtau: #editjam Minggu tutup" });
      return;
    }
    const day = args[0];
    const validDays = ["Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu"];
    if (!validDays.includes(day)) {
      await sock.sendMessage(jid, { text: `❌ Hari tidak valid. Gunakan: ${validDays.join(", ")}` });
      return;
    }
    const existing = DB.getOne("operating_hours", { day });
    if (!existing) { await sock.sendMessage(jid, { text: `❌ Data jam untuk hari ${day} tidak ditemukan.` }); return; }
    if (args[1].toLowerCase() === "tutup") {
      DB.update("operating_hours", { is_closed: 1 }, { day });
      await sock.sendMessage(jid, { text: `✅ Hari *${day}* ditandai sebagai TUTUP.` });
      return;
    }
    if (args[1].toLowerCase() === "buka") {
      DB.update("operating_hours", { is_closed: 0 }, { day });
      await sock.sendMessage(jid, { text: `✅ Hari *${day}* ditandai sebagai BUKA.` });
      return;
    }
    const openTime = args[1];
    const closeTime = args[2];
    if (!openTime || !closeTime || !/^\d{2}:\d{2}$/.test(openTime) || !/^\d{2}:\d{2}$/.test(closeTime)) {
      await sock.sendMessage(jid, { text: "❌ Format jam salah. Contoh: #editjam Senin 08:00 21:00" });
      return;
    }
    DB.update("operating_hours", { open_time: openTime, close_time: closeTime, is_closed: 0 }, { day });
    await sock.sendMessage(jid, { text: `✅ Jam operasional *${day}* berhasil diubah:\n🕐 Buka: ${openTime}\n🕕 Tutup: ${closeTime}` });
  },
};
