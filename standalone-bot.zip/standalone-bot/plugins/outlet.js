"use strict";
const { DB } = require("../database");

module.exports = {
  command: ["outlet", "lokasi"],
  description: "Lihat daftar outlet",
  usage: "#outlet",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const outlets = DB.get("outlets");
    if (!outlets.length) {
      await sock.sendMessage(jid, { text: "Informasi outlet belum tersedia." });
      return;
    }
    let text = `🏪 *OUTLET KAMI*\n${"═".repeat(30)}\n\n`;
    outlets.forEach((o, i) => {
      text += `*${i + 1}. ${o.name}*\n`;
      text += `📍 Alamat: ${o.address}\n`;
      if (o.maps_url) text += `🗺️ Maps: ${o.maps_url}\n`;
      if (o.whatsapp) text += `📱 WhatsApp: ${o.whatsapp}\n`;
      text += "\n";
    });
    text += `${"═".repeat(30)}\n_Ketik #jam untuk jam operasional_`;
    await sock.sendMessage(jid, { text });
  },
};
