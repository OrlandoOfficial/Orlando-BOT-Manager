"use strict";
const Settings = require("../settings");
const { DB } = require("../database");
const { formatRupiah } = require("../utils/format");

const state = new Map();

module.exports = {
  command: ["tambahproduk"],
  description: "Tambah produk baru (Admin)",
  usage: "#tambahproduk",
  category: "admin",
  async handleState(sock, jid, text) {
    const s = state.get(jid);
    if (!s) return false;
    const reply = async (msg) => sock.sendMessage(jid, { text: msg });
    if (s.step === "nama") { s.data.name = text; s.step = "harga"; await reply("💰 Harga produk (angka, contoh: 50000):"); return true; }
    if (s.step === "harga") { s.data.price = parseInt(text) || 0; s.step = "deskripsi"; await reply("📝 Deskripsi produk (atau 'skip'):"); return true; }
    if (s.step === "deskripsi") { s.data.description = text === "skip" ? null : text; s.step = "kategori"; await reply("🏷️ Kategori (atau 'skip'):"); return true; }
    if (s.step === "kategori") { s.data.category = text === "skip" ? null : text; s.step = "stok"; await reply("📦 Jumlah stok (angka):"); return true; }
    if (s.step === "stok") {
      s.data.stock = parseInt(text) || 0;
      state.delete(jid);
      DB.insert("products", s.data);
      await reply(`✅ Produk *${s.data.name}* berhasil ditambahkan!\n💰 Harga: ${formatRupiah(s.data.price)}\n📦 Stok: ${s.data.stock}`);
      return true;
    }
    return false;
  },
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    if (!Settings.isAdmin(jid)) { await sock.sendMessage(jid, { text: "❌ Akses ditolak." }); return; }
    state.set(jid, { step: "nama", data: {} });
    await sock.sendMessage(jid, { text: "🛍️ *TAMBAH PRODUK*\n\n📦 Nama produk:" });
  },
};
