"use strict";
const Settings = require("../settings");
const { DB } = require("../database");
const { formatRupiah } = require("../utils/format");

const state = new Map();

module.exports = {
  command: ["tambahtreatment"],
  description: "Tambah treatment (Admin)",
  usage: "#tambahtreatment",
  category: "admin",
  async handleState(sock, jid, text) {
    const s = state.get(jid);
    if (!s) return false;
    const reply = async (msg) => sock.sendMessage(jid, { text: msg });
    if (s.step === "nama") { s.data.name = text; s.step = "harga"; await reply("💰 Harga (angka):"); return true; }
    if (s.step === "harga") { s.data.price = parseInt(text) || 0; s.step = "durasi"; await reply("⏱️ Durasi (menit, atau 'skip'):"); return true; }
    if (s.step === "durasi") { s.data.duration = text === "skip" ? null : parseInt(text); s.step = "deskripsi"; await reply("📝 Deskripsi (atau 'skip'):"); return true; }
    if (s.step === "deskripsi") {
      s.data.description = text === "skip" ? null : text;
      state.delete(jid);
      DB.insert("treatments", s.data);
      await reply(`✅ Treatment *${s.data.name}* berhasil ditambahkan!\n💰 Harga: ${formatRupiah(s.data.price)}`);
      return true;
    }
    return false;
  },
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    if (!Settings.isAdmin(jid)) { await sock.sendMessage(jid, { text: "❌ Akses ditolak." }); return; }
    state.set(jid, { step: "nama", data: {} });
    await sock.sendMessage(jid, { text: "✂️ *TAMBAH TREATMENT*\n\nNama treatment:" });
  },
};
