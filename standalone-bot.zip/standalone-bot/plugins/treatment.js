"use strict";
const { DB } = require("../database");
const { formatRupiah } = require("../utils/format");

module.exports = {
  command: ["treatment"],
  description: "Lihat daftar treatment",
  usage: "#treatment",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const treatments = DB.get("treatments");
    if (!treatments.length) {
      await sock.sendMessage(jid, { text: "Belum ada treatment tersedia." });
      return;
    }
    let text = `✂️ *DAFTAR TREATMENT*\n${"═".repeat(30)}\n\n`;
    treatments.forEach((t, i) => {
      text += `*${i + 1}. ${t.name}*\n`;
      text += `💰 Harga: ${formatRupiah(t.price)}\n`;
      if (t.duration) text += `⏱️ Durasi: ${t.duration} menit\n`;
      if (t.description) text += `📝 ${t.description}\n`;
      text += "\n";
    });
    text += `${"═".repeat(30)}\n_Ketik #booking untuk reservasi_`;
    await sock.sendMessage(jid, { text });
  },
};
