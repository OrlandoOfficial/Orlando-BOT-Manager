"use strict";
const Settings = require("../settings");
const { DB } = require("../database");
const { formatDate } = require("../utils/format");

module.exports = {
  command: ["bookinglist", "daftarbooking"],
  description: "Lihat daftar booking (Admin)",
  usage: "#bookinglist",
  category: "admin",
  async execute(sock, msg, args) {
    const jid = msg.key.remoteJid;
    if (!Settings.isAdmin(jid)) {
      await sock.sendMessage(jid, { text: "❌ Akses ditolak." });
      return;
    }
    const status = args[0] || null;
    const bookings = status
      ? DB.get("bookings").filter((b) => b.status === status)
      : DB.get("bookings").slice(-10);
    if (!bookings.length) {
      await sock.sendMessage(jid, { text: "📋 Tidak ada booking ditemukan." });
      return;
    }
    const statusIcon = { pending: "⏳", confirmed: "✅", completed: "🎉", cancelled: "❌" };
    let text = `📋 *DAFTAR BOOKING*\n${"═".repeat(30)}\n\n`;
    bookings.reverse().forEach((b) => {
      text += `${statusIcon[b.status] || "•"} [${b.id}] *${b.booking_number}*\n`;
      text += `   👤 ${b.name} | 📅 ${b.date} ${b.time}\n`;
      text += `   Status: ${b.status.toUpperCase()}\n\n`;
    });
    text += `${"═".repeat(30)}\n_#bookingselesai [ID] | #bookingbatal [ID]_`;
    await sock.sendMessage(jid, { text });
  },
};
