"use strict";
const Settings = require("../settings");
const { formatRupiah } = require("../utils/format");

module.exports = {
  command: ["sewabot", "orderbot", "hargabot"],
  description: "Info sewa bot WhatsApp",
  usage: "#sewabot",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const price = Settings.getRentalPrice();
    const instagram = Settings.getRentalInstagram();
    const whatsapp = Settings.getRentalWhatsapp();
    const text = `🤖 *SEWA BOT WHATSAPP*\n${"═".repeat(30)}\n\n📦 *Fitur Bot:*\n✅ Menu Interaktif Lengkap\n✅ Sistem Booking Otomatis\n✅ Manajemen Produk & Treatment\n✅ Info Harga, Promo & Member\n✅ Dashboard Admin Web\n✅ REST API\n✅ Database SQLite/MySQL\n✅ Anti Spam & Auto Read\n✅ Broadcast Pesan\n✅ Backup Otomatis\n✅ Export/Import Excel\n✅ Multi Device (MD)\n✅ Support 24 Jam\n\n💰 *HARGA SEWA*\n${"─".repeat(20)}\n1 Bulan: ${formatRupiah(price)}\n\n📱 *HUBUNGI KAMI:*\n📸 Instagram: ${instagram}\n💬 WhatsApp: ${whatsapp}\n\n${"═".repeat(30)}\n_Developed by Orlando Gaming_\n_Copyright © Orlando Gaming_`;
    await sock.sendMessage(jid, { text });
  },
};
