"use strict";
const Settings = require("../settings");
const { DB } = require("../database");

const state = new Map();

module.exports = {
  command: ["tambahoutlet"],
  description: "Tambah outlet (Admin)",
  usage: "#tambahoutlet",
  category: "admin",
  async handleState(sock, jid, text) {
    const s = state.get(jid);
    if (!s) return false;
    const reply = async (msg) => sock.sendMessage(jid, { text: msg });
    if (s.step === "nama") { s.data.name = text; s.step = "alamat"; await reply("📍 Alamat outlet:"); return true; }
    if (s.step === "alamat") { s.data.address = text; s.step = "maps"; await reply("🗺️ Link Google Maps (atau 'skip'):"); return true; }
    if (s.step === "maps") { s.data.maps_url = text === "skip" ? null : text; s.step = "wa"; await reply("📱 Nomor WhatsApp outlet (atau 'skip'):"); return true; }
    if (s.step === "wa") {
      s.data.whatsapp = text === "skip" ? null : text;
      state.delete(jid);
      DB.insert("outlets", s.data);
      await reply(`✅ Outlet *${s.data.name}* berhasil ditambahkan!`);
      return true;
    }
    return false;
  },
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    if (!Settings.isAdmin(jid)) { await sock.sendMessage(jid, { text: "❌ Akses ditolak." }); return; }
    state.set(jid, { step: "nama", data: {} });
    await sock.sendMessage(jid, { text: "🏪 *TAMBAH OUTLET*\n\nNama outlet:" });
  },
};
