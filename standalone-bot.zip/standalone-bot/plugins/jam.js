"use strict";
const { DB } = require("../database");

module.exports = {
  command: ["jam", "buka", "tutup"],
  description: "Lihat jam operasional",
  usage: "#jam",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const hours = DB.get("operating_hours");
    if (!hours.length) {
      await sock.sendMessage(jid, { text: "Jam operasional belum tersedia." });
      return;
    }
    let text = `🕒 *JAM OPERASIONAL*\n${"═".repeat(30)}\n\n`;
    hours.forEach((h) => {
      const statusIcon = h.is_closed ? "🔴" : "🟢";
      const statusText = h.is_closed ? "LIBUR" : `${h.open_time} - ${h.close_time}`;
      text += `${statusIcon} *${h.day}*: ${statusText}\n`;
    });
    text += `\n${"═".repeat(30)}\n_Jadwal dapat berubah di hari libur nasional_`;
    await sock.sendMessage(jid, { text });
  },
};
