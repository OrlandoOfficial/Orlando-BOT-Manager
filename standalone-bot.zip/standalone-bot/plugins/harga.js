"use strict";
const { DB } = require("../database");
const { formatRupiah } = require("../utils/format");

module.exports = {
  command: ["harga"],
  description: "Lihat daftar harga",
  usage: "#harga",
  category: "customer",
  async execute(sock, msg) {
    const jid = msg.key.remoteJid;
    const prices = DB.get("prices");
    if (!prices.length) {
      await sock.sendMessage(jid, { text: "Daftar harga belum tersedia." });
      return;
    }
    // Group by category
    const grouped = {};
    prices.forEach((p) => {
      const cat = p.category || "Umum";
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push(p);
    });
    let text = `💰 *DAFTAR HARGA*\n${"═".repeat(30)}\n\n`;
    for (const [cat, items] of Object.entries(grouped)) {
      text += `📌 *${cat.toUpperCase()}*\n`;
      items.forEach((p) => { text += `  • ${p.service_name}: ${formatRupiah(p.price)}\n`; });
      text += "\n";
    }
    text += `${"═".repeat(30)}\n_Harga dapat berubah sewaktu-waktu_`;
    await sock.sendMessage(jid, { text });
  },
};
