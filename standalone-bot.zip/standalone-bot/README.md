# ✂️ Orlando Barbershop Bot

Bot WhatsApp profesional untuk manajemen barbershop — dibangun dengan Node.js + Baileys.

**Developed by Orlando Digital**  
📸 Instagram: @D_Orlando1  
💬 WhatsApp: 085742900949  
Copyright © Orlando Digital

---

## 📋 Daftar Isi

- [Cara Install](#-cara-install)
- [Cara Menjalankan](#-cara-menjalankan)
- [Cara Login QR](#-cara-login-qr)
- [Deploy ke Panel Pterodactyl](#-deploy-ke-panel-pterodactyl)
- [Konfigurasi Owner](#-konfigurasi-owner)
- [Konfigurasi Database](#-konfigurasi-database)
- [Konfigurasi REST API](#-konfigurasi-rest-api)
- [Backup & Restore Database](#-backup--restore-database)
- [Update Bot](#-update-bot)
- [Troubleshooting](#-troubleshooting)

---

## 📦 Cara Install

### Persyaratan

- **Node.js** v18.0.0 atau lebih baru (disarankan LTS)
- **npm** v8+ atau **pnpm**
- **Linux VPS** (Ubuntu 20.04/22.04) atau Windows

### Langkah Install

```bash
# 1. Clone atau download project ini
git clone <repository-url>
cd orlando-barbershop-bot

# 2. Install dependensi
npm install

# 3. Salin file konfigurasi
cp .env.example .env

# 4. Edit konfigurasi (lihat bagian Konfigurasi Owner)
nano .env

# 5. Jalankan bot
npm start
```

---

## ▶️ Cara Menjalankan

### Mode Normal
```bash
npm start
```

### Mode Development (auto-restart saat perubahan file)
```bash
npm run dev
```

### Jalankan dengan PM2 (production)
```bash
# Install PM2 global
npm install -g pm2

# Jalankan dengan PM2
pm2 start index.js --name "orlando-bot"

# Auto-start saat reboot
pm2 startup
pm2 save

# Lihat logs
pm2 logs orlando-bot

# Restart bot
pm2 restart orlando-bot

# Stop bot
pm2 stop orlando-bot
```

---

## 📲 Cara Login QR

### Metode 1: Terminal (Direkomendasikan)
1. Jalankan `npm start`
2. QR Code akan muncul di terminal
3. Buka WhatsApp di ponsel → **Menu (titik 3) → Perangkat tertaut → Tautkan perangkat**
4. Scan QR Code yang muncul di terminal
5. Bot akan online otomatis

### Metode 2: Via API
1. Jalankan bot
2. Akses `http://localhost:3000/api/whatsapp/qr`
3. Gunakan library QR code untuk menampilkan string QR
4. Scan dengan WhatsApp

### Metode 3: Via Dashboard Web
1. Buka `http://localhost:3000` di browser
2. Pergi ke halaman WhatsApp
3. QR akan ditampilkan otomatis saat bot belum terkoneksi

---

## 🦅 Deploy ke Panel Pterodactyl

### Persiapan
1. Login ke Panel Pterodactyl
2. Buat server baru dengan egg **Node.js**
3. Atur startup command: `node index.js`
4. Atur Node.js version: **18** atau lebih baru

### Konfigurasi Server Pterodactyl
- **Startup Command:** `node index.js`
- **Docker Image:** `ghcr.io/pterodactyl/yolks:nodejs_18`
- **Port:** `3000` (untuk REST API)
- **Allocated Memory:** minimal 512 MB

### Upload Files
1. Zip semua file project (kecuali `node_modules/` dan `session/`)
2. Upload via File Manager Pterodactyl
3. Ekstrak di root server
4. Buka Console Pterodactyl
5. Jalankan `npm install`
6. Edit `.env` via File Manager
7. Start server

### Environment Variables di Pterodactyl
Buka tab **Startup** di server Pterodactyl dan tambahkan:
```
OWNER_NUMBER=6285742900949
BOT_NAME=Orlando Barbershop Bot
DB_TYPE=sqlite
API_PORT=3000
```

---

## 👤 Konfigurasi Owner

Edit file `.env`:

```env
# Nomor WhatsApp owner (format internasional tanpa +)
# Contoh: 0812345678 → 62812345678
OWNER_NUMBER=6285742900949

# Admin tambahan (pisahkan koma)
ADMIN_NUMBERS=6285742900949,6281234567890

# Nama bot
BOT_NAME="Orlando Barbershop Bot"

# Prefix perintah (default: #)
PREFIX=#
```

**Penting:** Gunakan format nomor internasional (62xxx, bukan 08xxx)

---

## 🗄️ Konfigurasi Database

### SQLite (Default - Direkomendasikan)
```env
DB_TYPE=sqlite
SQLITE_PATH=./database/barbershop.db
```
Tidak perlu konfigurasi tambahan. Database otomatis dibuat saat pertama kali bot dijalankan.

### MySQL (Opsional)
```env
DB_TYPE=mysql
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=password_kamu
MYSQL_DATABASE=orlando_barbershop
```

Buat database MySQL terlebih dahulu:
```sql
CREATE DATABASE orlando_barbershop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

---

## 🔌 Konfigurasi REST API

REST API berjalan di port `3000` (default). Semua endpoint memerlukan header autentikasi:

```
X-API-Key: <nilai API_SECRET dari .env>
```

### Endpoint Utama

| Method | Endpoint | Deskripsi |
|--------|----------|-----------|
| GET | `/api/healthz` | Status server |
| GET | `/api/whatsapp/status` | Status koneksi bot |
| GET | `/api/whatsapp/qr` | QR Code untuk login |
| POST | `/api/whatsapp/broadcast` | Kirim broadcast |
| GET | `/api/bookings` | Daftar booking |
| POST | `/api/bookings` | Buat booking |
| GET | `/api/products` | Daftar produk |
| GET | `/api/treatments` | Daftar treatment |
| GET | `/api/stats/dashboard` | Statistik dashboard |

### Contoh Request

```bash
# Cek status bot
curl http://localhost:3000/api/whatsapp/status \
  -H "X-API-Key: orlando-secret-key"

# Daftar booking
curl http://localhost:3000/api/bookings \
  -H "X-API-Key: orlando-secret-key"

# Tambah produk
curl -X POST http://localhost:3000/api/products \
  -H "X-API-Key: orlando-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"name":"Pomade Premium","price":85000,"stock":50}'
```

---

## 💾 Backup & Restore Database

### Backup via WhatsApp
```
#backup
```

### Backup via API
```bash
curl -X POST http://localhost:3000/api/database/backup \
  -H "X-API-Key: orlando-secret-key"
```

### Lihat Daftar Backup
```bash
# Via WhatsApp
#listbackup

# Via API
curl http://localhost:3000/api/database/backups \
  -H "X-API-Key: orlando-secret-key"
```

### Restore via API
```bash
curl -X POST http://localhost:3000/api/database/restore \
  -H "X-API-Key: orlando-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"filename":"backup-2025-01-01T00-00-00.json"}'
```

### Backup Otomatis
Bot melakukan backup otomatis setiap 60 menit (dapat diubah di `.env`):
```env
AUTO_BACKUP_INTERVAL=60  # menit, 0 untuk nonaktifkan
```

File backup tersimpan di: `database/backups/`

---

## 🔄 Update Bot

```bash
# Backup database sebelum update
cp database/barbershop.db database/barbershop.db.bak

# Pull update terbaru
git pull

# Install dependensi baru (jika ada)
npm install

# Restart bot
pm2 restart orlando-bot
# atau
npm start
```

---

## 🛠️ Troubleshooting

### Bot tidak mau konek
1. Hapus folder `session/` dan scan QR ulang
2. Pastikan Node.js versi 18+
3. Cek koneksi internet VPS

### Error "Cannot find module"
```bash
rm -rf node_modules
npm install
```

### QR Code tidak muncul
- Cek apakah sesi sebelumnya masih ada di folder `session/`
- Hapus `session/` dan restart bot

### Bot tidak merespons perintah
1. Pastikan prefix di `.env` sesuai (`#` by default)
2. Cek nomor owner sudah benar (format 62xxx)
3. Lihat logs: `pm2 logs orlando-bot`

### Database error
- Pastikan folder `database/` ada dan bisa ditulis
- Untuk SQLite: cek path di `.env`
- Untuk MySQL: cek kredensial dan pastikan database sudah dibuat

### Port 3000 sudah dipakai
```env
API_PORT=4000  # ganti ke port lain
```

### Memory tinggi
- Kurangi `AUTO_BACKUP_INTERVAL` atau nonaktifkan (`0`)
- Gunakan PM2 dengan `max-memory-restart`: `pm2 start index.js --max-memory-restart 512M`

---

## 📝 Perintah WhatsApp

### Pelanggan
| Perintah | Deskripsi |
|----------|-----------|
| `#menu` | Menu utama |
| `#booking` | Buat booking |
| `#treatment` | Daftar treatment |
| `#produk` | Daftar produk |
| `#harga` | Daftar harga |
| `#outlet` | Info outlet |
| `#karyawan` | Daftar karyawan |
| `#jam` | Jam operasional |
| `#promo` | Promo aktif |
| `#member` | Info member |
| `#sewabot` | Info sewa bot |
| `#kontak` | Kontak kami |

### Admin/Owner
| Perintah | Deskripsi |
|----------|-----------|
| `#admin` | Menu admin |
| `#bookinglist` | Daftar booking |
| `#bookingselesai [ID]` | Tandai selesai |
| `#bookingbatal [ID]` | Tandai batal |
| `#bookinghapus [ID]` | Hapus booking |
| `#tambahproduk` | Tambah produk |
| `#tambahtreatment` | Tambah treatment |
| `#tambahoutlet` | Tambah outlet |
| `#tambahkaryawan` | Tambah karyawan |
| `#editjam [Hari] [buka] [tutup]` | Edit jam operasional |
| `#broadcast [pesan]` | Kirim broadcast |
| `#backup` | Backup database |
| `#listbackup` | Daftar backup |

---

## 📞 Dukungan

Butuh bantuan atau ingin sewa bot ini?

- 📸 **Instagram:** @D_Orlando1
- 💬 **WhatsApp:** 085742900949

**Copyright © Orlando Digital**
