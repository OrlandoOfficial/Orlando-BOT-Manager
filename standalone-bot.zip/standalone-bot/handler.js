"use strict";
const path = require("path");
const fs = require("fs");
const Settings = require("./settings");
const { checkSpam } = require("./utils/antiSpam");
const logger = require("./utils/logger");

// Load all plugins
const pluginsDir = path.join(__dirname, "plugins");
const plugins = [];
const stateHandlers = []; // plugins with multi-step state

function loadPlugins() {
  const files = fs.readdirSync(pluginsDir).filter((f) => f.endsWith(".js"));
  for (const file of files) {
    try {
      const plugin = require(path.join(pluginsDir, file));
      if (plugin.command) {
        plugins.push(plugin);
        if (typeof plugin.handleState === "function") {
          stateHandlers.push(plugin);
        }
        logger.debug(`Plugin loaded: ${file}`);
      }
    } catch (e) {
      logger.warn(`Failed to load plugin ${file}: ${e.message}`);
    }
  }
  logger.info(`Loaded ${plugins.length} plugins`);
}

async function handleMessage(sock, msg) {
  try {
    const jid = msg.key.remoteJid;
    const isGroup = jid.endsWith("@g.us");
    const senderJid = isGroup ? msg.key.participant : jid;

    // Extract text
    const body = msg.message?.conversation
      || msg.message?.extendedTextMessage?.text
      || msg.message?.imageMessage?.caption
      || msg.message?.videoMessage?.caption
      || "";

    if (!body) return;

    // Auto read
    if (Settings.isAutoRead()) {
      await sock.readMessages([msg.key]);
    }

    // Anti spam
    if (checkSpam(senderJid)) {
      logger.debug(`Spam blocked: ${senderJid}`);
      return;
    }

    const prefix = Settings.getPrefix();

    // Check multi-step state handlers first
    for (const handler of stateHandlers) {
      if (await handler.handleState(sock, jid, body)) {
        return;
      }
    }

    // Check if message starts with prefix
    if (!body.startsWith(prefix)) {
      // Welcome message for first message
      if (Settings.isAutoReply() && !isGroup) {
        const welcomeMsg = Settings.getWelcomeMessage();
        // Only send welcome on very first message (simple check)
        if (body.toLowerCase().includes("halo") || body.toLowerCase().includes("hi") || body.toLowerCase().includes("hai")) {
          await sock.sendMessage(jid, { text: welcomeMsg });
        }
      }
      return;
    }

    // Parse command
    const parts = body.slice(prefix.length).trim().split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);

    // Find plugin
    const plugin = plugins.find((p) => p.command.includes(cmd));
    if (!plugin) {
      if (Settings.isAutoReply()) {
        await sock.sendMessage(jid, { text: `❓ Perintah *${prefix}${cmd}* tidak ditemukan.\nKetik *${prefix}menu* untuk melihat daftar perintah.` });
      }
      return;
    }

    // Execute plugin
    logger.info(`Command: ${prefix}${cmd} from ${senderJid}`);
    await plugin.execute(sock, msg, args, cmd);
  } catch (err) {
    logger.error({ err }, "Error handling message");
  }
}

module.exports = { loadPlugins, handleMessage };
