"use strict";

function formatRupiah(amount) {
  return "Rp" + Number(amount).toLocaleString("id-ID");
}

function generateBookingNumber() {
  const now = new Date();
  const y = String(now.getFullYear()).slice(-2);
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  const rand = String(Math.floor(Math.random() * 10000)).padStart(4, "0");
  return `ORB-${y}${m}${d}-${rand}`;
}

function formatDate(dateStr) {
  if (!dateStr) return "-";
  const d = new Date(dateStr);
  return d.toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
}

function formatTime(timeStr) {
  return timeStr || "-";
}

function divider(char = "═", length = 30) {
  return char.repeat(length);
}

module.exports = { formatRupiah, generateBookingNumber, formatDate, formatTime, divider };
