"use strict";
const fs = require("fs");
const path = require("path");
const config = require("../config");

const BACKUP_DIR = path.resolve("./database/backups");

function ensureDir() {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

function createBackup(DB) {
  ensureDir();
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const filename = `backup-${timestamp}.json`;
  const filepath = path.join(BACKUP_DIR, filename);
  const data = {
    created_at: new Date().toISOString(),
    outlets: DB.get("outlets"),
    treatments: DB.get("treatments"),
    products: DB.get("products"),
    staff: DB.get("staff"),
    prices: DB.get("prices"),
    promos: DB.get("promos"),
    members: DB.get("members"),
    bookings: DB.get("bookings"),
    operating_hours: DB.get("operating_hours"),
    bot_settings: DB.get("bot_settings"),
  };
  fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
  const stat = fs.statSync(filepath);
  return { filename, created_at: data.created_at, size: stat.size };
}

function listBackups() {
  ensureDir();
  return fs
    .readdirSync(BACKUP_DIR)
    .filter((f) => f.endsWith(".json"))
    .map((f) => {
      const stat = fs.statSync(path.join(BACKUP_DIR, f));
      return { filename: f, created_at: stat.mtime.toISOString(), size: stat.size };
    })
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
}

function restoreBackup(DB, filename) {
  const filepath = path.join(BACKUP_DIR, filename);
  if (!fs.existsSync(filepath)) throw new Error("Backup tidak ditemukan: " + filename);
  const data = JSON.parse(fs.readFileSync(filepath, "utf8"));
  // Clear & restore each table
  const tables = ["outlets", "treatments", "products", "staff", "prices", "promos", "members", "bookings", "operating_hours"];
  for (const table of tables) {
    if (data[table] && Array.isArray(data[table])) {
      // SQLite only — MySQL would need different approach
      if (config.dbType === "sqlite") {
        const Database = require("better-sqlite3");
        const rawDb = Database(path.resolve(config.sqlitePath));
        rawDb.prepare(`DELETE FROM ${table}`).run();
        for (const row of data[table]) {
          const { id, ...rest } = row;
          const keys = Object.keys(rest);
          if (keys.length) {
            rawDb.prepare(`INSERT OR REPLACE INTO ${table} (id, ${keys.join(", ")}) VALUES (${id}, ${keys.map(() => "?").join(", ")})`).run(...Object.values(rest));
          }
        }
        rawDb.close();
      }
    }
  }
  return true;
}

module.exports = { createBackup, listBackups, restoreBackup };
