"use strict";
const config = require("../config");

const spamMap = new Map(); // jid -> { count, lastTime }

function checkSpam(jid) {
  if (!config.antiSpam) return false;
  const now = Date.now();
  const entry = spamMap.get(jid) || { count: 0, lastTime: 0 };
  if (now - entry.lastTime < config.antiSpamDelay) {
    entry.count++;
    spamMap.set(jid, entry);
    return entry.count > 3; // blocked if more than 3 msgs in delay window
  }
  spamMap.set(jid, { count: 1, lastTime: now });
  return false;
}

function resetSpam(jid) {
  spamMap.delete(jid);
}

module.exports = { checkSpam, resetSpam };
